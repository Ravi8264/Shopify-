/**
 * Product Page JavaScript
 * Handles all dynamic functionality for the custom product page
 */

class ProductPage {
  constructor() {
    this.productData = window.productData || {};
    this.currentSubscription = 'single';
    this.selectedFlavors = ['Chocolate'];
    this.basePrice = 0;
    this.subscriptionDiscount = 0.25; // 25%
    this.salesDiscount = 0.20; // 20%
    
    this.init();
  }

  init() {
    this.setupEventListeners();
    this.initializeDefaultSelections();
    this.updatePricing();
    this.updateFlavorSummary();
    this.updateWhatsIncluded();
  }

  setupEventListeners() {
    // Subscription type changes
    document.querySelectorAll('.subscription-radio').forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.currentSubscription = e.target.value;
        this.updateFlavorSelectors();
        this.updatePricing();
        this.updateWhatsIncluded();
        this.updateVariantSelection();
      });
    });

    // Flavor selection changes
    document.querySelectorAll('.flavor-radio').forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.updateSelectedFlavors();
        this.updateFlavorSummary();
        this.updatePricing();
        this.updateVariantSelection();
      });
    });

    // Quantity changes
    const quantityInput = document.getElementById('quantity');
    if (quantityInput) {
      quantityInput.addEventListener('change', () => {
        this.updatePricing();
      });
    }

    // Add to cart form submission
    const addToCartForm = document.querySelector('.product-form');
    if (addToCartForm) {
      addToCartForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.addToCart();
      });
    }
  }

  initializeDefaultSelections() {
    // Set default subscription to single
    const singleRadio = document.getElementById('single-drink');
    if (singleRadio) {
      singleRadio.checked = true;
      this.currentSubscription = 'single';
    }

    // Set default flavor to chocolate
    const chocolateRadio = document.getElementById('flavor-chocolate');
    if (chocolateRadio) {
      chocolateRadio.checked = true;
      this.selectedFlavors = ['Chocolate'];
    }

    // Update UI based on defaults
    this.updateFlavorSelectors();
    this.updatePricing();
    this.updateFlavorSummary();
    this.updateWhatsIncluded();
    this.updateVariantSelection();
  }

  updateFlavorSelectors() {
    const singleSection = document.getElementById('single-flavor-section');
    const doubleSection = document.getElementById('double-flavor-section');

    if (this.currentSubscription === 'single') {
      if (singleSection) singleSection.style.display = 'block';
      if (doubleSection) doubleSection.style.display = 'none';
    } else {
      if (singleSection) singleSection.style.display = 'none';
      if (doubleSection) doubleSection.style.display = 'block';
    }
  }

  updateSelectedFlavors() {
    this.selectedFlavors = [];
    
    if (this.currentSubscription === 'single') {
      const selectedFlavor = document.querySelector('input[name="flavor-1"]:checked');
      if (selectedFlavor) {
        this.selectedFlavors = [selectedFlavor.value];
      }
    } else {
      const flavor1 = document.querySelector('input[name="flavor-1-double"]:checked');
      const flavor2 = document.querySelector('input[name="flavor-2-double"]:checked');
      
      if (flavor1) this.selectedFlavors.push(flavor1.value);
      if (flavor2) this.selectedFlavors.push(flavor2.value);
    }
  }

  updateFlavorSummary() {
    const summaryElement = document.getElementById('selected-flavors');
    if (summaryElement) {
      summaryElement.textContent = this.selectedFlavors.join(', ');
    }
  }

  updatePricing() {
    // Get base price from product data
    this.basePrice = this.getBasePrice();
    
    // Calculate pricing based on subscription type
    const quantity = parseInt(document.getElementById('quantity')?.value || 1);
    const multiplier = this.currentSubscription === 'double' ? 2 : 1;
    
    const baseTotal = this.basePrice * multiplier * quantity;
    const subscriptionPrice = baseTotal * (1 - this.subscriptionDiscount);
    const finalPrice = subscriptionPrice * (1 - this.salesDiscount);
    
    const subscriptionDiscountAmount = baseTotal - subscriptionPrice;
    const salesDiscountAmount = subscriptionPrice - finalPrice;
    const totalSavings = subscriptionDiscountAmount + salesDiscountAmount;

    // Update price displays
    this.updatePriceDisplay('base-price', baseTotal);
    this.updatePriceDisplay('subscription-discount', subscriptionDiscountAmount);
    this.updatePriceDisplay('sales-discount', salesDiscountAmount);
    this.updatePriceDisplay('final-price', finalPrice);
    this.updatePriceDisplay('current-price', finalPrice);
    this.updatePriceDisplay('original-price', baseTotal);
    
    // Update savings display
    this.updateSavingsDisplay(totalSavings);
    
    // Update option prices
    this.updateOptionPrices();
    
    // Update add to cart button
    this.updateAddToCartButton(finalPrice);
  }

  getBasePrice() {
    // Try to get price from product variants
    if (this.productData.variants && this.productData.variants.length > 0) {
      return parseFloat(this.productData.variants[0].price) / 100; // Shopify prices are in cents
    }
    
    // Fallback to a default price
    return 100.00;
  }

  updatePriceDisplay(elementId, price) {
    const element = document.getElementById(elementId);
    if (element) {
      element.textContent = this.formatPrice(price);
    }
  }

  updateSavingsDisplay(savings) {
    const savingsContainer = document.getElementById('savings-container');
    const savingsAmount = document.getElementById('savings-amount');
    const originalPriceContainer = document.getElementById('original-price-container');
    
    if (savings > 0) {
      if (savingsContainer) {
        savingsContainer.style.display = 'block';
        savingsAmount.textContent = `Save ${this.formatPrice(savings)}`;
      }
      if (originalPriceContainer) {
        originalPriceContainer.style.display = 'block';
      }
    } else {
      if (savingsContainer) savingsContainer.style.display = 'none';
      if (originalPriceContainer) originalPriceContainer.style.display = 'none';
    }
  }

  updateOptionPrices() {
    const basePrice = this.getBasePrice();
    const singlePrice = basePrice * (1 - this.subscriptionDiscount) * (1 - this.salesDiscount);
    const doublePrice = singlePrice * 2;
    
    const singlePriceElement = document.querySelector('[data-price="single"]');
    const doublePriceElement = document.querySelector('[data-price="double"]');
    
    if (singlePriceElement) {
      singlePriceElement.textContent = this.formatPrice(singlePrice);
    }
    if (doublePriceElement) {
      doublePriceElement.textContent = this.formatPrice(doublePrice);
    }
  }

  updateAddToCartButton(price) {
    const button = document.querySelector('.add-to-cart-btn');
    const btnText = document.querySelector('.btn-text');
    const btnPrice = document.querySelector('.btn-price');
    
    if (button && btnText && btnPrice) {
      const isValid = this.selectedFlavors.length > 0;
      button.disabled = !isValid;
      
      if (isValid) {
        btnText.textContent = 'Add to Cart';
        btnPrice.textContent = ` - ${this.formatPrice(price)}`;
      } else {
        btnText.textContent = 'Select Options';
        btnPrice.textContent = '';
      }
    }
  }

  updateWhatsIncluded() {
    const singleContent = document.getElementById('single-included-content');
    const doubleContent = document.getElementById('double-included-content');
    
    if (this.currentSubscription === 'single') {
      if (singleContent) singleContent.style.display = 'block';
      if (doubleContent) doubleContent.style.display = 'none';
    } else {
      if (singleContent) singleContent.style.display = 'none';
      if (doubleContent) doubleContent.style.display = 'block';
    }
  }

  updateVariantSelection() {
    // Find the appropriate variant based on selected flavors
    const selectedVariantId = this.findVariantId();
    const variantInput = document.getElementById('selected-variant-id');
    
    if (variantInput && selectedVariantId) {
      variantInput.value = selectedVariantId;
    }
  }

  findVariantId() {
    if (!this.productData.variants) return null;
    
    // For single subscription, find variant with matching flavor
    if (this.currentSubscription === 'single') {
      const flavor = this.selectedFlavors[0];
      return this.productData.variants.find(variant => 
        variant.option1 === flavor || variant.option2 === flavor || variant.option3 === flavor
      )?.id;
    }
    
    // For double subscription, we might need to handle multiple variants
    // This is a simplified approach - in a real implementation, you'd need to handle
    // the specific variant structure based on your product setup
    return this.productData.variants[0]?.id;
  }

  async addToCart() {
    const form = document.querySelector('.product-form');
    const formData = new FormData(form);
    
    try {
      const response = await fetch('/cart/add.js', {
        method: 'POST',
        body: formData
      });
      
      if (response.ok) {
        const result = await response.json();
        this.showSuccessMessage('Product added to cart successfully!');
        this.updateCartCount();
      } else {
        throw new Error('Failed to add to cart');
      }
    } catch (error) {
      console.error('Error adding to cart:', error);
      this.showErrorMessage('Failed to add product to cart. Please try again.');
    }
  }

  showSuccessMessage(message) {
    // Create and show success message
    const messageDiv = document.createElement('div');
    messageDiv.className = 'success-message';
    messageDiv.textContent = message;
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
      messageDiv.remove();
    }, 3000);
  }

  showErrorMessage(message) {
    // Create and show error message
    const messageDiv = document.createElement('div');
    messageDiv.className = 'error-message';
    messageDiv.textContent = message;
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
      messageDiv.remove();
    }, 3000);
  }

  async updateCartCount() {
    try {
      const response = await fetch('/cart.js');
      const cart = await response.json();
      
      // Update cart count in header if it exists
      const cartCountElement = document.querySelector('.cart-count');
      if (cartCountElement) {
        cartCountElement.textContent = cart.item_count;
      }
    } catch (error) {
      console.error('Error updating cart count:', error);
    }
  }

  formatPrice(price) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  window.ProductPage = new ProductPage();
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ProductPage;
} 